
Dukung channel dengan cara Subscribe, like dan komen ... ( gratis kok bos ) 

aktifkan juga lonceng nya, biar gak ketinggalan video yang lain.



> [![Deploy](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new?template=https://github.com/mrbogel/Student)


Terima kasih buat yang udah Subscribe ...
